<!-- END wrapper -->
<!-- bundle -->
<script src="<?php echo $DIR ?>assets/js/vendor.min.js"></script>
<script src="<?php echo $DIR ?>assets/js/app.min.js"></script>

<!-- third party js -->
<script src="<?php echo $DIR ?>assets/js/vendor/apexcharts.min.js"></script>
<script src="<?php echo $DIR ?>assets/js/vendor/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?php echo $DIR ?>assets/js/vendor/jquery-jvectormap-world-mill-en.js"></script>
<script src="<?php echo $DIR ?>assets/js/vendor/jquery.dataTables.min.js"></script>
<script src="<?php echo $DIR ?>assets/js/vendor/handlebars.min.js"></script>
<script src="<?php echo $DIR ?>assets/js/vendor/typeahead.bundle.min.js"></script>
<!-- third party js ends -->
<!-- Runnables -->
<script src="<?php echo $DIR ?>assets/js/pages/demo.toastr.js"></script>
<script src="<?php echo $DIR ?>assets/js/pages/demo.typehead.js"></script>
<!-- Custom / Backend Scripts Actions -->