<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="<?php echo $CONFIG['META_DESC']; ?>" name="description" />
<meta content="<?php echo $CONFIG['AUTHOR']; ?>" name="author" />
<!-- App favicon -->
<link rel="shortcut icon" href="<?php echo $DIR ?>assets/images/favicon.ico">

<!-- third party css -->
<link href="<?php echo $DIR ?>assets/libs/Font-Awsome-6/css/all.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $DIR ?>assets/css/vendor/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $DIR ?>assets/css/vendor/dataTables.bootstrap5.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $DIR ?>assets/css/vendor/responsive.bootstrap5.css" rel="stylesheet" type="text/css" />
<!-- third party css end -->

<!-- App css -->
<link href="<?php echo $DIR ?>assets/css/icons.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $DIR ?>assets/css/app.min.css" rel="stylesheet" type="text/css" id="app-style" />
<link href="<?php echo $DIR ?>assets/css/bootstrap.css" rel="stylesheet" type="text/css" id="app-style" />
<link href="<?php echo $DIR ?>assets/css/custom.css" rel="stylesheet" type="text/css" id="app-style" />