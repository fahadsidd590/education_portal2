</div>
</div>
</div>
<?php require_once("{$DIR}COMPONENTS/footer-resourses.php"); ?>
</body>

</html>