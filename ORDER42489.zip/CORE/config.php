<?php
define('DBNAME', "education_portal2");
define('DBUSER', "root");
define('DBPASS', "");
define('DBHOST', "localhost");
